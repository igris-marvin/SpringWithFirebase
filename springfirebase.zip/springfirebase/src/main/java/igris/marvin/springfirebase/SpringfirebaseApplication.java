package igris.marvin.springfirebase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringfirebaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringfirebaseApplication.class, args);
	}

}
