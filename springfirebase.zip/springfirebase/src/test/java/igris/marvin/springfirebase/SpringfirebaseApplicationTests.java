package igris.marvin.springfirebase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringfirebaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
